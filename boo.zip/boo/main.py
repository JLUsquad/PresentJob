from BooStructure import BooStructure
booStructure=BooStructure('/home/william/workspace/boo/1-ICSD-108.cif').getBooStructure()
print(booStructure)
# from boo import Boo
# import numpy as np 
# a=np.array([1,1,1])
# s=Boo(vec=a).getBoo()
# print(s)